package com.teamtreehouse.techdegree;

import com.teamtreehouse.techdegree.hardware.FrightMachine;

public class Main {

    public static void main(String[] args) {
        FrightMachine machine = new FrightMachine();
        machine.simulateMotion();
    }
}
