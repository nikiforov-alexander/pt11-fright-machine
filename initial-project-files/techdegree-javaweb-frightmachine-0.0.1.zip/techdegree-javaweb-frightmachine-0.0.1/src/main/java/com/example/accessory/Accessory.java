package com.example.accessory;

public interface Accessory {
    public void activate();
}
